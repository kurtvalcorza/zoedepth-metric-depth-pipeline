"""P2: run the reviewed notebook's BYOD path (cell 9 with USE_BYOD = True, then the cell-11 validation) as committed,
torch-free, against realistic uploads. `google.colab.files.upload` is replaced by a stand-in returning the given ZIP.
Cases: well-formed 8 and 4 records; a ZIP made by compressing a folder (top-level directory prefix); sparse depth with
zeros for missing pixels (KITTI/NYU-raw convention); depth stored in millimetres; a cancelled upload dialog; no Colab.
Usage: python p2_byod.py <repo> <out.json>
"""
import io, json, subprocess, sys, types, zipfile
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
sys.path.insert(0, str(repo / 'src'))
import zoedepth_metric_depth_pipeline as zp

NB = 'tutorials/zoedepth_metric_depth_colab.ipynb'
blob = subprocess.run(['git', '-C', str(repo), 'rev-parse', f'HEAD:{NB}'], capture_output=True, text=True).stdout.strip()
nb = json.loads(subprocess.run(['git', '-C', str(repo), 'cat-file', '-p', blob], capture_output=True, text=True).stdout)
cell9 = ''.join(nb['cells'][9]['source']).replace('USE_BYOD = False', 'USE_BYOD = True', 1)
cell11 = ''.join(nb['cells'][11]['source']).replace("os.makedirs('outputs', exist_ok=True)", '').replace(
    "with open('outputs/zoedepth_metric_depth_dataset_manifest.json', 'w', encoding='utf-8') as handle:\n    json.dump(dataset_manifest, handle, indent=2)\n", '')
assert 'USE_BYOD = True' in cell9


def make_zip(n, prefix='', depth=lambda i: np.full((96, 128), 1.5 + 0.1 * i, np.float32)):
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w') as z:
        for i in range(n):
            im = io.BytesIO(); Image.new('RGB', (128, 96), (10 * i, 80, 160)).save(im, 'PNG')
            z.writestr(f'{prefix}images/scene_{i:02d}.png', im.getvalue())
            d = io.BytesIO(); np.save(d, depth(i)); z.writestr(f'{prefix}depth/scene_{i:02d}.npy', d.getvalue())
    return buf.getvalue()


def sparse(i):
    d = np.full((96, 128), 3.0 + 0.1 * i, np.float32); d[::2, :] = 0.0  # zeros mark missing LiDAR returns
    return d


def run(uploaded, colab=True):
    for m in ('google', 'google.colab'):
        sys.modules.pop(m, None)
    if colab:
        g = types.ModuleType('google'); c = types.ModuleType('google.colab')
        c.files = types.SimpleNamespace(upload=lambda: uploaded); g.colab = c
        sys.modules['google'] = g; sys.modules['google.colab'] = c
    ns = {k: getattr(zp, k) for k in dir(zp) if not k.startswith('__')}
    ns.update(MAX_ADAPTATION_RECORDS=zp.pipeline.MAX_ADAPTATION_RECORDS, MAX_ADAPTATION_PIXELS=zp.pipeline.MAX_ADAPTATION_PIXELS)
    try:
        exec(cell9, ns)
        r = {'reader': 'ok', 'records': len(ns['dataset_records']), 'train': len(ns['train_records']), 'held_out': len(ns['val_records']),
             'held_out_ids': [x['id'] for x in ns['val_records']]}
    except BaseException as e:
        return {'reader': f'{type(e).__name__}: {e}'}
    try:
        exec(cell11.replace('print(json.dumps(dataset_manifest, indent=2))', ''), ns)
        r['validation'] = 'accepted'
    except BaseException as e:
        r['validation'] = f'{type(e).__name__}: {e}'
    return r


res = {'notebook_blob': blob, 'cases': {
    'well_formed_8_records': run({'d.zip': make_zip(8)}),
    'well_formed_4_records': run({'d.zip': make_zip(4)}),
    'folder_compressed_with_top_level_dir': run({'d.zip': make_zip(12, prefix='my_rgbd/')}),
    'sparse_depth_zero_for_missing_12_records': run({'d.zip': make_zip(12, depth=sparse)}),
    'depth_in_millimetres_12_records': run({'d.zip': make_zip(12, depth=lambda i: np.full((96, 128), 1500 + 100 * i, np.float32))}),
    'cancelled_upload_dialog': run({}),
    'outside_colab': run(None, colab=False),
}}
json.dump(res, open(out, 'w'), indent=1)
print(json.dumps(res, indent=1))
