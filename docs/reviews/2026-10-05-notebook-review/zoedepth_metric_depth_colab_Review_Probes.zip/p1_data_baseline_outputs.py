"""P1: torch-free re-derivation of everything in the reviewed notebook's default path that does not need the model,
checked against the saved outputs of the recorded Kaggle T4 run (docs/verification/2026-09-18-kaggle-t4, v9).

- executes cell 9 (generated data and 75/25 split) and the cell-11 validation exactly as committed in the blob;
- recomputes the constant-training-median baseline AbsRel and delta1 on the held-out split (cell 13 formula);
- recomputes the unseen-scene AbsRel/delta1 from the committed unseen prediction (.npy) and the regenerated reference,
  and describes how the prediction relates to the reference (range, correlation, a constant-at-its-own-median control);
- parses the committed adapter.safetensors header (no torch) and checks the manifest digest binding;
- re-hashes the preserved outputs against the README table.
Usage: python p1_data_baseline_outputs.py <repo> <out.json>
"""
import hashlib, json, subprocess, sys, struct
from pathlib import Path
import numpy as np

repo, out = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
sys.path.insert(0, str(repo / 'src'))
import zoedepth_metric_depth_pipeline as zp  # pipeline imports numpy and PIL only at module level

NB = 'tutorials/zoedepth_metric_depth_colab.ipynb'
blob = subprocess.run(['git', '-C', str(repo), 'rev-parse', f'HEAD:{NB}'], capture_output=True, text=True).stdout.strip()
nb = json.loads(subprocess.run(['git', '-C', str(repo), 'cat-file', '-p', blob], capture_output=True, text=True).stdout)
src = lambda i: ''.join(nb['cells'][i]['source'])
EV = repo / 'docs/verification/2026-09-18-kaggle-t4/suite/dimer-nb2-zoedepth-metric-depth/v9/evidence'
res = {'notebook_blob': blob}

ns = {k: getattr(zp, k) for k in dir(zp) if not k.startswith('__')}
ns.update(MAX_ADAPTATION_RECORDS=zp.pipeline.MAX_ADAPTATION_RECORDS, MAX_ADAPTATION_PIXELS=zp.pipeline.MAX_ADAPTATION_PIXELS,
          _valid_mask=zp.pipeline._valid_mask)
exec(src(9), ns)
train, val = ns['train_records'], ns['val_records']
tm, vm = zp.validate_depth_dataset(train), zp.validate_depth_dataset(val)
saved = json.load(open(EV / 'outputs/zoedepth_metric_depth_dataset_manifest.json'))
res['dataset'] = {'records': len(ns['dataset_records']), 'train': len(train), 'held_out': len(val),
                  'train_ids': [r['id'] for r in train][-2:], 'held_out_ids': [r['id'] for r in val],
                  'train_median_m': tm['depth_median_m'],
                  'train_sha256_matches_saved': tm['dataset_sha256'] == saved['train']['dataset_sha256'],
                  'val_sha256_matches_saved': vm['dataset_sha256'] == saved['validation']['dataset_sha256']}

med = tm['depth_median_m']; ab = hits = n = 0
for r in val:
    ref = np.asarray(r['depth_m'], dtype=np.float64); base = np.full_like(ref, med)
    ab += float(np.sum(np.abs(base - ref) / ref)); hits += int(np.sum(np.maximum(base / ref, ref / base) < 1.25)); n += ref.size
rep = json.load(open(EV / 'outputs/zoedepth_metric_depth_evaluation_report.json'))
res['constant_median_baseline'] = {'abs_rel': ab / n, 'delta1': hits / n, 'valid_pixels': n,
                                   'saved_abs_rel': rep['baseline_pretrained']['constant_median_baseline_abs_rel'],
                                   'saved_delta1': rep['baseline_pretrained']['constant_median_baseline_delta1']}
res['saved_scores'] = {'pretrained': {k: rep['baseline_pretrained'][k] for k in ('abs_rel', 'delta1')},
                       'adapted': {k: rep['adapted'][k] for k in ('abs_rel', 'delta1')},
                       'adapted_minus_pretrained_abs_rel': rep['adapted']['abs_rel'] - rep['baseline_pretrained']['abs_rel'],
                       'pretrained_minus_constant_delta1': rep['baseline_pretrained']['delta1'] - rep['baseline_pretrained']['constant_median_baseline_delta1'],
                       'adapted_minus_constant_abs_rel': rep['adapted']['abs_rel'] - rep['adapted']['constant_median_baseline_abs_rel']}
result = json.load(open(EV / 'outputs/zoedepth_metric_depth_result.json'))
res['training_signal'] = {'baseline_validation_log_l1': result['adaptation']['baseline_validation_log_l1'],
                          'history': result['adaptation']['history']}

unseen = ns['generated_depth_records'](start=24, count=1)[0]
pred = np.load(EV / 'outputs/zoedepth_metric_depth_unseen_depth.npy').astype(np.float64)
ref = unseen['depth_m'].astype(np.float64)
const = np.full_like(ref, float(np.median(pred)))
res['unseen'] = {'id': unseen['id'], 'abs_rel': zp.abs_rel(pred, ref), 'delta1': zp.delta1(pred, ref),
                 'saved_abs_rel': result['unseen']['abs_rel'], 'saved_delta1': result['unseen']['delta1'],
                 'reference_range_m': [float(ref.min()), float(ref.max())], 'prediction_range_m': [float(pred.min()), float(pred.max())],
                 'reference_std_m': float(ref.std()), 'prediction_std_m': float(pred.std()),
                 'pearson_pred_ref': float(np.corrcoef(pred.ravel(), ref.ravel())[0, 1]),
                 'row_profile_m': {'reference_top_row_mean': float(ref[0].mean()), 'reference_bottom_row_mean': float(ref[-1].mean()),
                                   'prediction_top_row_mean': float(pred[0].mean()), 'prediction_bottom_row_mean': float(pred[-1].mean())},
                 'pearson_row_index_vs_reference': float(np.corrcoef(np.mgrid[:ref.shape[0], :ref.shape[1]][0].ravel(), ref.ravel())[0, 1]),
                 'pearson_row_index_vs_prediction': float(np.corrcoef(np.mgrid[:ref.shape[0], :ref.shape[1]][0].ravel(), pred.ravel())[0, 1]),
                 'control_constant_at_prediction_median': {'abs_rel': zp.abs_rel(const, ref), 'delta1': zp.delta1(const, ref)}}

ad = EV / 'outputs/zoedepth-metric-head-adapter-v1'
raw = (ad / 'adapter.safetensors').read_bytes(); hl = struct.unpack('<Q', raw[:8])[0]
hdr = json.loads(raw[8:8 + hl]); tensors = {k: v for k, v in hdr.items() if k != '__metadata__'}
man = json.load(open(ad / 'manifest.json'))
res['adapter'] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                  'manifest_sha256': man['files'][0]['sha256'], 'manifest_bytes': man['files'][0]['bytes'],
                  'tensors': len(tensors), 'all_metric_head': all(k.startswith('metric_head.') for k in tensors),
                  'parameters': int(sum(int(np.prod(v['shape'])) for v in tensors.values())),
                  'dtypes': sorted({v['dtype'] for v in tensors.values()})}
table = {'zoedepth_metric_depth_dataset_manifest.json': 'aeafa65db08d19608a42c35f376461fd1b008b8ce4b3bf0dfd1da7c391c6504e',
         'zoedepth_metric_depth_evaluation_report.json': 'e6aef1a2fd807a98d105aec8556a8dbf49960389fb839b8590c24fdf3938de08',
         'zoedepth_metric_depth_result.json': '46ffd43c89e7c65cdb6570bd6a8c686cec9fdb3abf6ff92d138fbf57c8aea76b',
         'zoedepth_metric_depth_unseen_depth.npy': 'bf567631c415c99d7b16a99b893bfa3e5439a57eea66600bca2b40a8db4a2e5a',
         'zoedepth-metric-head-adapter-v1/adapter.safetensors': 'c16d4600249b26db8f79fff0bfae6db00b75d3feb4ef57fb731acd2a0e2f9cac',
         'zoedepth-metric-head-adapter-v1/manifest.json': 'fb44a9058d9b4e7e300f165dcb5c392d10709d86cac16aa1700c580a453219c5'}
res['preserved_output_hashes_match_readme'] = {k: hashlib.sha256((EV / 'outputs' / k).read_bytes()).hexdigest() == v for k, v in table.items()}
ex = json.load(open(EV / 'executed.ipynb'))
res['executed_notebook_sources_equal_blob'] = [''.join(c['source']) for c in ex['cells']] == [''.join(c['source']) for c in nb['cells']]
json.dump(res, open(out, 'w'), indent=1, default=float)
print(json.dumps(res, indent=1, default=float))
